#include <iostream>

using namespace std;
using std :: cin;
using std :: string;

int main() {
  string name;
  cout <<"introduce tu nombre";
  cin >> name;
  cout <<"hola" <<name ;
}